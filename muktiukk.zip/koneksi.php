<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'telpon';
$koneksi = mysqli_connect($host, $username, $password, $database);
